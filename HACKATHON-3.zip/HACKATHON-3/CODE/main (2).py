import time
import threading
from collections import defaultdict

# Define the Auction class
class Auction:
    def __init__(self, item, start_price, auctioneer, reserve_price=None, buy_now_price=None, bid_increment=1, duration=None):
        self.item = item
        self.current_price = start_price
        self.current_bidder = None
        self.auctioneer = auctioneer
        self.is_active = True
        self.reserve_price = reserve_price
        self.buy_now_price = buy_now_price
        self.bid_increment = bid_increment
        self.bidders = defaultdict(int)  # To store bidder's highest bid
        self.bid_history = []  # List of bids
        self.start_time = time.time()
        self.duration = duration  # Auction time limit in seconds
        self.end_time = None if duration is None else self.start_time + duration
        self.blacklist = set()

    def place_bid(self, bidder_name, bid_amount):
        if bidder_name in self.blacklist:
            print(f"{bidder_name} is blacklisted and cannot place a bid.")
            return

        if not self.is_active:
            print(f"The auction for {self.item} has ended.")
            return
        
        # Buy Now functionality
        if self.buy_now_price and bid_amount >= self.buy_now_price:
            self.current_price = self.buy_now_price
            self.current_bidder = bidder_name
            print(f"{bidder_name} bought {self.item} for {self.buy_now_price} with Buy Now!")
            self.bid_history.append((bidder_name, self.buy_now_price))
            self.close_auction()
            return
        
        if bid_amount < self.current_price + self.bid_increment:
            print(f"Bid must be at least {self.current_price + self.bid_increment}.")
            return
        
        self.current_price = bid_amount
        self.current_bidder = bidder_name
        self.bidders[bidder_name] = bid_amount
        self.bid_history.append((bidder_name, bid_amount))
        print(f"{bidder_name} placed a bid of {bid_amount}!")

    def auto_close(self):
        if self.end_time and time.time() >= self.end_time:
            self.close_auction()

    def close_auction(self):
        self.is_active = False
        if self.current_price >= self.reserve_price:
            print(f"Auction closed! {self.item} sold to {self.current_bidder} for {self.current_price}.")
        else:
            print(f"Auction closed! Reserve price not met, {self.item} not sold.")
        self.show_summary()

    def auction_status(self):
        print(f"Auction for {self.item}: Current highest bid is {self.current_price} by {self.current_bidder}.")
        if self.end_time:
            remaining_time = self.end_time - time.time()
            print(f"Time remaining: {int(remaining_time)} seconds.")

    def blacklist_bidder(self, bidder_name):
        self.blacklist.add(bidder_name)
        print(f"{bidder_name} has been blacklisted.")

    def show_bid_history(self):
        print(f"Bid history for {self.item}:")
        for bid in self.bid_history:
            print(f"{bid[0]} placed a bid of {bid[1]}")

    def show_summary(self):
        print(f"Auction summary for {self.item}:")
        if self.current_bidder:
            print(f"Sold to {self.current_bidder} for {self.current_price}")
        else:
            print("No valid bids were placed.")
        self.show_bid_history()

# User class for storing ratings and blacklist status
class User:
    def __init__(self, name):
        self.name = name
        self.rating = 0
        self.blacklisted = False
    
    def update_rating(self, score):
        self.rating += score
        print(f"{self.name}'s rating updated to {self.rating}.")

    def blacklist(self):
        self.blacklisted = True
        print(f"{self.name} has been blacklisted.")

# Auction management functions
def create_auction(auctioneer):
    item = input("Enter the item name for auction: ")
    start_price = float(input("Enter the starting price: "))
    reserve_price = float(input("Enter the reserve price (or press Enter to skip): ") or 0)
    buy_now_price = float(input("Enter the Buy Now price (or press Enter to skip): ") or 0)
    bid_increment = float(input("Enter minimum bid increment: "))
    duration = int(input("Enter auction duration in seconds (or press Enter for no time limit): ") or 0)
    auction = Auction(item, start_price, auctioneer, reserve_price, buy_now_price, bid_increment, duration)
    return auction

def participate_in_auction(auction):
    print(f"Auction started for {auction.item}.")
    
    def auto_close_timer(auction):
        while auction.is_active:
            time.sleep(1)
            auction.auto_close()

    if auction.duration:
        threading.Thread(target=auto_close_timer, args=(auction,)).start()

    while auction.is_active:
        auction.auction_status()
        action = input("Enter 'bid' to place a bid, 'close' to end auction, 'buy' for Buy Now, 'status' to view current status, 'history' for bid history, or 'blacklist' to blacklist a bidder: ").strip().lower()
        
        # Handle actions
        if action == 'bid':
            bidder_name = input("Enter your name: ")
            bid_amount = float(input("Enter your bid amount: "))
            auction.place_bid(bidder_name, bid_amount)
        elif action == 'close':
            auction.close_auction()
        elif action == 'buy':
            if auction.buy_now_price:
                bidder_name = input("Enter your name: ")
                auction.place_bid(bidder_name, auction.buy_now_price)
            else:
                print("This item does not have a Buy Now option.")
        elif action == 'status':
            auction.auction_status()
        elif action == 'history':
            auction.show_bid_history()
        elif action == 'blacklist':
            bidder_name = input("Enter the name of the bidder to blacklist: ")
            auction.blacklist_bidder(bidder_name)
        else:
            print("Invalid action. Try again.")
        time.sleep(1)

def main():
    auctioneer_name = input("Enter auctioneer name: ")
    auctioneer = User(auctioneer_name)
    auction = create_auction(auctioneer)
    participate_in_auction(auction)

if __name__ == "__main__":
    main()
